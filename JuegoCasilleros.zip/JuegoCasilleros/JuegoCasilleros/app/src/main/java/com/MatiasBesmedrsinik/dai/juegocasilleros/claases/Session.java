package com.MatiasBesmedrsinik.dai.juegocasilleros.claases;

public class Session {
    public static String Nombre="";
    public static String Ape="";
    public static String logica=" ";
    public static int cont=0;
    public static String estado="";


}
